//
// Created by kcr12_000 on 3/10/2017.
//

#ifndef CLEAN
#define CLEAN

void clean_stdin();

#endif // CLEAN
